const { Prediction } = require("../config/models");
const { MENUS, con, end, getSession, saveSession, getOrCreateUser } = require("../services/sessionService");
const { PACKAGES, requestPayment } = require("../services/momoService");

// ─── Fetch today's predictions from DB ───────────────────────
async function getTodaysPredictions() {
  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);
  const endOfDay = new Date();
  endOfDay.setHours(23, 59, 59, 999);

  return Prediction.find({
    matchDate: { $gte: startOfDay, $lte: endOfDay },
    isActive: true,
  }).limit(8);
}

// ─── Main USSD Handler ────────────────────────────────────────
async function handleUSSD({ sessionId, phoneNumber, text, serviceCode }) {
  // Split input text into navigation parts
  // e.g. "1*2" means user chose 1 then 2
  const parts = text ? text.split("*") : [];
  const lastInput = parts[parts.length - 1] || "";

  const session = await getSession(sessionId, phoneNumber);
  const user = await getOrCreateUser(phoneNumber);
  const isVIP = user.checkVIPStatus();

  // ── MAIN MENU ─────────────────────────────────────────────
  if (!text || text === "") {
    await saveSession(session, MENUS.MAIN);
    return con(
      `⚽ BetTips GH\nWelcome, ${isVIP ? "👑 VIP Member" : "Free User"}!\n\n` +
      `1. Free Daily Tips\n` +
      `2. VIP Predictions\n` +
      `3. My Account\n` +
      `4. Help / Contact`
    );
  }

  // ── FREE TIPS ─────────────────────────────────────────────
  if (parts[0] === "1") {
    if (parts.length === 1) {
      const predictions = await getTodaysPredictions();
      if (!predictions.length) {
        return end("No predictions available today.\nCheck back later. ⚽");
      }
      const list = predictions
        .map((p, i) => `${i + 1}. ${p.match}`)
        .join("\n");
      await saveSession(session, MENUS.FREE_TIPS, { predictions: predictions.map(p => p._id) });
      return con(`🆓 Free Tips Today:\n\n${list}\n\n0. Back`);
    }

    if (parts.length === 2) {
      const idx = parseInt(parts[1]) - 1;
      const predictions = await getTodaysPredictions();
      if (isNaN(idx) || idx < 0 || idx >= predictions.length) {
        return end("Invalid option. Please try again.");
      }
      const p = predictions[idx];
      return end(
        `📊 ${p.match}\n` +
        `🏆 ${p.league}\n\n` +
        `Tip: ${p.tipFree}\n` +
        `Odds: ${p.oddsFree}\n\n` +
        `⚠️ Bet Responsibly.\nFor correct scores, get VIP!\nDial *714# again.`
      );
    }
  }

  // ── VIP MENU ──────────────────────────────────────────────
  if (parts[0] === "2") {

    // View VIP tips
    if (parts[1] === "1") {
      if (!isVIP) {
        return end(
          `🔒 VIP Access Required\n\n` +
          `You need an active subscription.\n` +
          `Dial *714# and choose:\n` +
          `2 > 2 to subscribe.\n\n` +
          `Packages from GHS 2/day!`
        );
      }

      const predictions = await getTodaysPredictions();

      if (parts.length === 2) {
        if (!predictions.length) return end("No VIP tips today. Check back later.");
        const list = predictions.map((p, i) => `${i + 1}. ${p.match}`).join("\n");
        return con(`👑 VIP Tips Today:\n\n${list}\n\n0. Back`);
      }

      if (parts.length === 3) {
        const idx = parseInt(parts[2]) - 1;
        if (isNaN(idx) || idx < 0 || idx >= predictions.length) {
          return end("Invalid option.");
        }
        const p = predictions[idx];
        return end(
          `🎯 ${p.match}\n` +
          `🏆 ${p.league}\n\n` +
          `VIP Tip: ${p.tipVIP}\n` +
          `Odds: ${p.oddsVIP}\n` +
          `Confidence: ${p.confidence} 🔥\n\n` +
          `⚠️ Bet Responsibly.`
        );
      }
    }

    // Subscribe
    if (parts[1] === "2") {
      if (parts.length === 2) {
        return con(
          `💳 Choose VIP Package:\n\n` +
          `1. Daily  - GHS 2.00  (1 day)\n` +
          `2. Weekly - GHS 10.00 (7 days)\n` +
          `3. Monthly- GHS 35.00 (30 days)\n\n` +
          `0. Back`
        );
      }

      const pkgMap = { "1": "DAILY", "2": "WEEKLY", "3": "MONTHLY" };
      const pkgCode = pkgMap[parts[2]];

      if (parts.length === 3) {
        if (!pkgCode) return end("Invalid package selected.");
        const pkg = PACKAGES[pkgCode];
        return con(
          `✅ Confirm Payment\n\n` +
          `Package: ${pkg.name}\n` +
          `Amount:  GHS ${pkg.amount}.00\n` +
          `Duration: ${pkg.days} day(s)\n\n` +
          `Billed via MTN MoMo\n\n` +
          `1. Confirm & Pay\n` +
          `2. Cancel`
        );
      }

      if (parts.length === 4 && parts[3] === "1") {
        try {
          await requestPayment(phoneNumber, pkgCode);
          const pkg = PACKAGES[pkgCode];
          return end(
            `⏳ Payment Request Sent!\n\n` +
            `GHS ${pkg.amount}.00 will be\n` +
            `deducted from your MTN MoMo.\n\n` +
            `Approve the prompt on your\n` +
            `phone to activate VIP.\n\n` +
            `Dial *714# after payment. ⚽`
          );
        } catch (err) {
          console.error("MoMo payment error:", err.message);
          return end(
            `❌ Payment failed.\n` +
            `Please try again later.\n` +
            `Call 0244000000 for help.`
          );
        }
      }

      if (parts.length === 4 && parts[3] === "2") {
        return end("Payment cancelled.\nDial *714# to try again.");
      }
    }

    // Main VIP menu (parts.length === 1)
    if (parts.length === 1) {
      return con(
        `👑 VIP Predictions\n` +
        `🔒 Premium Correct Scores\n\n` +
        `1. View Today's VIP Tips\n` +
        `2. Subscribe to VIP\n\n` +
        `0. Back`
      );
    }
  }

  // ── MY ACCOUNT ────────────────────────────────────────────
  if (parts[0] === "3") {
    const vipStatus = isVIP ? "👑 Active VIP" : "🆓 Free User";
    const expiry = user.vipExpiry
      ? new Date(user.vipExpiry).toLocaleDateString("en-GH")
      : "N/A";
    return end(
      `👤 My Account\n\n` +
      `Phone: ${phoneNumber}\n` +
      `Status: ${vipStatus}\n` +
      `VIP Expiry: ${expiry}\n` +
      `Total Subs: ${user.totalSubscriptions}\n\n` +
      `Dial *714# to subscribe.`
    );
  }

  // ── HELP ──────────────────────────────────────────────────
  if (parts[0] === "4") {
    return end(
      `❓ BetTips GH Help\n\n` +
      `📞 Call: 0244000000\n` +
      `💬 WhatsApp: 0554000000\n` +
      `📧 bettips@ghana.com\n\n` +
      `Hours: Mon-Fri 8am-8pm\n` +
      `Sat-Sun: 9am-6pm\n\n` +
      `⚠️ 18+ only. Bet Responsibly.`
    );
  }

  // ── FALLBACK ──────────────────────────────────────────────
  return end("Invalid option.\nDial *714# to start again.");
}

module.exports = { handleUSSD };
