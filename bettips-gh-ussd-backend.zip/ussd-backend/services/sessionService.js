const { Session, User } = require("../config/models");

// ─── Menu Constants ───────────────────────────────────────────
const MENUS = {
  MAIN: "MAIN",
  FREE_TIPS: "FREE_TIPS",
  FREE_TIP_DETAIL: "FREE_TIP_DETAIL",
  VIP_MENU: "VIP_MENU",
  VIP_TIPS: "VIP_TIPS",
  VIP_TIP_DETAIL: "VIP_TIP_DETAIL",
  VIP_SUBSCRIBE: "VIP_SUBSCRIBE",
  VIP_CONFIRM: "VIP_CONFIRM",
  MY_ACCOUNT: "MY_ACCOUNT",
  HELP: "HELP",
  NOT_SUBSCRIBED: "NOT_SUBSCRIBED",
};

// ─── Response Helpers ─────────────────────────────────────────
// CON = continue session, END = end session
const con = (text) => `CON ${text}`;
const end = (text) => `END ${text}`;

// ─── Session Helpers ──────────────────────────────────────────
async function getSession(sessionId, phoneNumber) {
  let session = await Session.findOne({ sessionId });
  if (!session) {
    session = await Session.create({ sessionId, phoneNumber, currentMenu: MENUS.MAIN, data: {} });
  }
  return session;
}

async function saveSession(session, menu, data = {}) {
  session.currentMenu = menu;
  session.data = { ...session.data, ...data };
  session.expiresAt = new Date(Date.now() + 5 * 60 * 1000);
  await session.save();
}

async function getOrCreateUser(phoneNumber) {
  let user = await User.findOne({ phoneNumber });
  if (!user) {
    user = await User.create({ phoneNumber });
  }
  user.lastActive = new Date();
  await user.save();
  return user;
}

module.exports = { MENUS, con, end, getSession, saveSession, getOrCreateUser };
