const axios = require("axios");
const { v4: uuidv4 } = require("uuid");
const { Subscription, User } = require("../config/models");

const BASE_URL = process.env.MTN_MOMO_BASE_URL;
const SUBSCRIPTION_KEY = process.env.MTN_MOMO_SUBSCRIPTION_KEY;
const API_USER = process.env.MTN_MOMO_API_USER;
const API_KEY = process.env.MTN_MOMO_API_KEY;
const CALLBACK_URL = process.env.MTN_MOMO_CALLBACK_URL;
const ENVIRONMENT = process.env.MTN_MOMO_ENVIRONMENT || "sandbox";

const PACKAGES = {
  DAILY:   { name: "Daily VIP",   amount: 2,  days: 1  },
  WEEKLY:  { name: "Weekly VIP",  amount: 10, days: 7  },
  MONTHLY: { name: "Monthly VIP", amount: 35, days: 30 },
};

// ─── Get OAuth token ─────────────────────────────────────────
async function getAccessToken() {
  const credentials = Buffer.from(`${API_USER}:${API_KEY}`).toString("base64");

  const response = await axios.post(
    `${BASE_URL}/collection/token/`,
    {},
    {
      headers: {
        Authorization: `Basic ${credentials}`,
        "Ocp-Apim-Subscription-Key": SUBSCRIPTION_KEY,
      },
    }
  );
  return response.data.access_token;
}

// ─── Request to Pay (debit customer) ─────────────────────────
async function requestPayment(phoneNumber, packageCode) {
  const pkg = PACKAGES[packageCode];
  if (!pkg) throw new Error("Invalid package");

  const referenceId = uuidv4();
  const token = await getAccessToken();

  // Format phone: 024XXXXXXX → 23324XXXXXXX (Ghana +233)
  const msisdn = phoneNumber.replace(/^0/, "233");

  await axios.post(
    `${BASE_URL}/collection/v1_0/requesttopay`,
    {
      amount: String(pkg.amount),
      currency: "GHS",
      externalId: referenceId,
      payer: { partyIdType: "MSISDN", partyId: msisdn },
      payerMessage: `BetTips GH - ${pkg.name}`,
      payeeNote: `Subscription: ${pkg.name}`,
    },
    {
      headers: {
        Authorization: `Bearer ${token}`,
        "X-Reference-Id": referenceId,
        "X-Target-Environment": ENVIRONMENT,
        "X-Callback-Url": CALLBACK_URL,
        "Ocp-Apim-Subscription-Key": SUBSCRIPTION_KEY,
        "Content-Type": "application/json",
      },
    }
  );

  // Save pending subscription record
  await Subscription.create({
    phoneNumber,
    package: packageCode,
    amount: pkg.amount,
    momoReferenceId: referenceId,
    status: "PENDING",
  });

  return referenceId;
}

// ─── Check payment status ─────────────────────────────────────
async function checkPaymentStatus(referenceId) {
  const token = await getAccessToken();

  const response = await axios.get(
    `${BASE_URL}/collection/v1_0/requesttopay/${referenceId}`,
    {
      headers: {
        Authorization: `Bearer ${token}`,
        "X-Target-Environment": ENVIRONMENT,
        "Ocp-Apim-Subscription-Key": SUBSCRIPTION_KEY,
      },
    }
  );
  return response.data; // { status: "SUCCESSFUL" | "FAILED" | "PENDING", ... }
}

// ─── Activate VIP after successful payment ────────────────────
async function activateVIP(phoneNumber, packageCode, transactionId) {
  const pkg = PACKAGES[packageCode];
  const now = new Date();
  const expiry = new Date(now.getTime() + pkg.days * 24 * 60 * 60 * 1000);

  // Update subscription
  await Subscription.findOneAndUpdate(
    { phoneNumber, status: "PENDING" },
    { status: "SUCCESSFUL", momoTransactionId: transactionId, startDate: now, endDate: expiry },
    { sort: { createdAt: -1 } }
  );

  // Update user
  await User.findOneAndUpdate(
    { phoneNumber },
    { isVIP: true, vipExpiry: expiry, $inc: { totalSubscriptions: 1 } }
  );
}

// ─── Handle MoMo webhook callback ─────────────────────────────
async function handleMoMoCallback(payload) {
  const { externalId, status, financialTransactionId } = payload;

  const sub = await Subscription.findOne({ momoReferenceId: externalId });
  if (!sub) return;

  if (status === "SUCCESSFUL") {
    await activateVIP(sub.phoneNumber, sub.package, financialTransactionId);
  } else if (status === "FAILED") {
    sub.status = "FAILED";
    await sub.save();
  }
}

module.exports = { PACKAGES, requestPayment, checkPaymentStatus, activateVIP, handleMoMoCallback };
