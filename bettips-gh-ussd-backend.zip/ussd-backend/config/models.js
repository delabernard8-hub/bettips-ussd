const mongoose = require("mongoose");

// ─── User Model ───────────────────────────────────────────────
const userSchema = new mongoose.Schema(
  {
    phoneNumber: { type: String, required: true, unique: true, index: true },
    network: { type: String, default: "MTN" },
    isVIP: { type: Boolean, default: false },
    vipExpiry: { type: Date, default: null },
    totalSubscriptions: { type: Number, default: 0 },
    lastActive: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

// Check if VIP is still active
userSchema.methods.checkVIPStatus = function () {
  if (!this.vipExpiry) return false;
  const active = new Date() < new Date(this.vipExpiry);
  if (!active && this.isVIP) {
    this.isVIP = false;
    this.save();
  }
  return active;
};

// ─── Subscription Model ───────────────────────────────────────
const subscriptionSchema = new mongoose.Schema(
  {
    phoneNumber: { type: String, required: true, index: true },
    package: {
      type: String,
      enum: ["DAILY", "WEEKLY", "MONTHLY"],
      required: true,
    },
    amount: { type: Number, required: true },
    currency: { type: String, default: "GHS" },
    status: {
      type: String,
      enum: ["PENDING", "SUCCESSFUL", "FAILED"],
      default: "PENDING",
    },
    momoReferenceId: { type: String },
    momoTransactionId: { type: String },
    startDate: { type: Date },
    endDate: { type: Date },
  },
  { timestamps: true }
);

// ─── Prediction Model ─────────────────────────────────────────
const predictionSchema = new mongoose.Schema(
  {
    match: { type: String, required: true },
    league: { type: String, required: true },
    tipFree: { type: String, required: true },       // e.g. "Home Win"
    tipVIP: { type: String, required: true },         // e.g. "Correct Score: 2-0"
    oddsFree: { type: String },
    oddsVIP: { type: String },
    confidence: { type: String },                     // e.g. "92%"
    matchDate: { type: Date, required: true },
    isActive: { type: Boolean, default: true },
    result: { type: String, default: null },          // filled after match
  },
  { timestamps: true }
);

// ─── Session Model (track USSD sessions) ─────────────────────
const sessionSchema = new mongoose.Schema(
  {
    sessionId: { type: String, required: true, unique: true },
    phoneNumber: { type: String, required: true },
    currentMenu: { type: String, default: "MAIN" },
    data: { type: mongoose.Schema.Types.Mixed, default: {} }, // temp data per session
    expiresAt: {
      type: Date,
      default: () => new Date(Date.now() + 5 * 60 * 1000), // 5 min TTL
    },
  },
  { timestamps: true }
);

sessionSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 }); // auto-delete expired

module.exports = {
  User: mongoose.model("User", userSchema),
  Subscription: mongoose.model("Subscription", subscriptionSchema),
  Prediction: mongoose.model("Prediction", predictionSchema),
  Session: mongoose.model("Session", sessionSchema),
};
