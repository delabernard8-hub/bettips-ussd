require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const rateLimit = require("express-rate-limit");

const ussdRoutes = require("./routes/ussd");
const momoRoutes = require("./routes/momo");
const adminRoutes = require("./routes/admin");

const app = express();
const PORT = process.env.PORT || 3000;

// ─── Middleware ───────────────────────────────────────────────
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rate limiting — protect USSD endpoint
const ussdLimiter = rateLimit({
  windowMs: 1 * 60 * 1000, // 1 minute
  max: 60,
  message: "Too many requests",
});

// ─── Routes ──────────────────────────────────────────────────
app.use("/ussd", ussdLimiter, ussdRoutes);
app.use("/api/momo", momoRoutes);
app.use("/api/admin", adminRoutes);

app.get("/", (req, res) => {
  res.json({ service: "BetTips GH USSD", status: "running", code: "*714#" });
});

// ─── MongoDB ─────────────────────────────────────────────────
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => {
    console.log("✅ MongoDB connected");
    app.listen(PORT, () => {
      console.log(`🚀 USSD Server running on port ${PORT}`);
      console.log(`📞 Short code: ${process.env.USSD_SHORT_CODE}`);
    });
  })
  .catch((err) => {
    console.error("❌ MongoDB connection failed:", err.message);
    process.exit(1);
  });

module.exports = app;
