const express = require("express");
const router = express.Router();
const { handleUSSD } = require("../services/ussdHandler");

/**
 * POST /ussd
 * MTN Ghana USSD Gateway sends POST requests with these fields:
 *   sessionId   - unique ID for the session
 *   serviceCode - the short code e.g. 714
 *   phoneNumber - caller's number e.g. 0244123456
 *   text        - accumulated input e.g. "1*2*1"
 *   networkCode - MTN
 *   type        - "initiation" | "response" | "release" | "timeout"
 */
router.post("/", async (req, res) => {
  // Support both form-encoded and JSON body (some gateways differ)
  const body = req.body;

  const sessionId   = body.sessionId   || body.SessionID;
  const serviceCode = body.serviceCode || body.ServiceCode;
  const phoneNumber = body.phoneNumber || body.PhoneNumber || body.msisdn;
  const text        = body.text        || body.Text        || "";
  const type        = body.type        || body.Type        || "response";

  // Validate required fields
  if (!sessionId || !phoneNumber) {
    return res.status(400).send("END Missing required parameters.");
  }

  // Handle session timeout or release
  if (type === "timeout" || type === "release") {
    return res.status(200).send("END Session ended. Dial *714# to start again.");
  }

  try {
    const response = await handleUSSD({ sessionId, phoneNumber, text, serviceCode });

    // MTN gateway expects plain text response: "CON ..." or "END ..."
    res.set("Content-Type", "text/plain");
    res.status(200).send(response);
  } catch (err) {
    console.error("USSD handler error:", err);
    res.status(200).send("END Service error. Please try again. Call 0244000000.");
  }
});

module.exports = router;
