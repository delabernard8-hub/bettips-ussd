const express = require("express");
const router = express.Router();
const { handleMoMoCallback } = require("../services/momoService");

/**
 * POST /api/momo/callback
 * MTN MoMo API calls this after payment is processed.
 * Payload includes: externalId, status, financialTransactionId, etc.
 */
router.post("/callback", async (req, res) => {
  try {
    const payload = req.body;
    console.log("MoMo callback received:", JSON.stringify(payload));

    await handleMoMoCallback(payload);

    res.status(200).json({ message: "OK" });
  } catch (err) {
    console.error("MoMo callback error:", err.message);
    res.status(500).json({ error: "Callback processing failed" });
  }
});

/**
 * GET /api/momo/status/:referenceId
 * Check payment status manually (for debugging or polling)
 */
router.get("/status/:referenceId", async (req, res) => {
  const { checkPaymentStatus } = require("../services/momoService");
  try {
    const status = await checkPaymentStatus(req.params.referenceId);
    res.json(status);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
