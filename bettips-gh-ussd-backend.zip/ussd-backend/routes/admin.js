const express = require("express");
const router = express.Router();
const { Prediction, User, Subscription } = require("../config/models");

// ─── Simple API key auth middleware ──────────────────────────
function adminAuth(req, res, next) {
  const key = req.headers["x-admin-secret"] || req.query.secret;
  if (key !== process.env.ADMIN_SECRET) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  next();
}

router.use(adminAuth);

// ─── Add a new prediction ─────────────────────────────────────
// POST /api/admin/predictions
// Body: { match, league, tipFree, tipVIP, oddsFree, oddsVIP, confidence, matchDate }
router.post("/predictions", async (req, res) => {
  try {
    const prediction = await Prediction.create(req.body);
    res.status(201).json({ success: true, prediction });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ─── Get all today's predictions ─────────────────────────────
router.get("/predictions", async (req, res) => {
  const { date } = req.query;
  const targetDate = date ? new Date(date) : new Date();
  targetDate.setHours(0, 0, 0, 0);
  const endDate = new Date(targetDate);
  endDate.setHours(23, 59, 59, 999);

  const predictions = await Prediction.find({
    matchDate: { $gte: targetDate, $lte: endDate },
  });
  res.json(predictions);
});

// ─── Update a prediction ──────────────────────────────────────
router.put("/predictions/:id", async (req, res) => {
  try {
    const prediction = await Prediction.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json({ success: true, prediction });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ─── Delete a prediction ──────────────────────────────────────
router.delete("/predictions/:id", async (req, res) => {
  await Prediction.findByIdAndDelete(req.params.id);
  res.json({ success: true });
});

// ─── Dashboard stats ──────────────────────────────────────────
router.get("/stats", async (req, res) => {
  const [totalUsers, vipUsers, totalSubs, successfulSubs] = await Promise.all([
    User.countDocuments(),
    User.countDocuments({ isVIP: true }),
    Subscription.countDocuments(),
    Subscription.countDocuments({ status: "SUCCESSFUL" }),
  ]);

  const revenue = await Subscription.aggregate([
    { $match: { status: "SUCCESSFUL" } },
    { $group: { _id: null, total: { $sum: "$amount" } } },
  ]);

  res.json({
    users: { total: totalUsers, vip: vipUsers },
    subscriptions: { total: totalSubs, successful: successfulSubs },
    revenue: revenue[0]?.total || 0,
  });
});

// ─── List all users ───────────────────────────────────────────
router.get("/users", async (req, res) => {
  const users = await User.find().sort({ createdAt: -1 }).limit(100);
  res.json(users);
});

module.exports = router;
